// all images imported from images directory
import product_01_image_01 from '../images/product_01.jpg';
import product_01_image_02 from '../images/product_01.1.jpg';
import product_01_image_03 from '../images/product_01.3.jpg';

import product_02_image_01 from '../images/product_2.1.jpg';
import product_02_image_02 from '../images/product_2.2.jpg';
import product_02_image_03 from '../images/product_2.3.jpg';

import product_03_image_01 from '../images/product_3.1.jpg';
import product_03_image_02 from '../images/product_3.2.jpg';
import product_03_image_03 from '../images/product_3.3.jpg';

import product_04_image_01 from '../images/product_4.1.jpg';
import product_04_image_02 from '../images/product_4.2.jpg';
import product_04_image_03 from '../images/product_4.3.png';

import product_05_image_01 from '../images/product_04.jpg';
import product_05_image_02 from '../images/product_08.jpg';
import product_05_image_03 from '../images/product_09.jpg';

import product_06_image_01 from '../images/bread(1).png';
import product_06_image_02 from '../images/bread(2).png';
import product_06_image_03 from '../images/bread(3).png';

const products = [
  {
    id: '01',
    title: 'Chicken Burger',
    price: 24.0,
    image01: './images/product_01.jpg',
    image02: './images/product_01.1.jpg',
    image03: './images/product_01.3.jpg',
    category: 'Burger',

    desc: 'Savor the juiciness and irresistible flavor of our Chicken Burger. Made with succulent grilled chicken breast, nestled between two soft and toasted buns, and layered with fresh lettuce, tomatoes, and a tangy special sauce. This mouthwatering burger is a perfect blend of savory and satisfying, delivering a delightful taste experience. Order our Chicken Burger now and treat yourself to a delicious and fulfilling meal. ',
  },

  {
    id: '02',
    title: 'Vegetarian Pizza',
    price: 115.0,
    image01: './images/product_2.1.jpg',
    image02: './images/product_2.2.jpg',
    image03: './images/product_2.3.jpg',
    category: 'Pizza',

    desc: 'Indulge in the flavorsome delight of our Vegetarian Pizza. Topped with a medley of garden-fresh vegetables, including bell peppers, mushrooms, onions, and juicy tomatoes, all nestled on a crispy crust smothered with tangy tomato sauce and melted cheese. This vegetarian delight is a perfect choice for those seeking a mouthwatering and satisfying pizza experience. Order our Vegetarian Pizza now and enjoy a burst of veggie goodness delivered right to your doorstep.',
  },

  {
    id: '03',
    title: 'Double Cheese Margherita',
    price: 110.0,
    image01: './images/product_3.1.jpg',
    image02: './images/product_3.2.jpg',
    image03: './images/product_3.3.jpg',
    category: 'Pizza',

    desc: "Experience the ultimate cheesy delight with our Double Cheese Margherita pizza. Featuring a classic combination of rich tomato sauce, double the amount of creamy mozzarella cheese, and a sprinkle of aromatic basil leaves on a thin and crispy crust. This pizza is a cheese lover's dream, delivering a perfect harmony of flavors. Order our Double Cheese Margherita and treat yourself to a delightful and cheesy indulgence.",
  },

  {
    id: '04',
    title: 'Mexican Green Wave',
    price: 110.0,
    image01: './images/product_4.1.jpg',
    image02: './images/product_4.2.jpg',
    image03: './images/product_4.3.png',
    category: 'Pizza',

    desc: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Soluta ad et est, fugiat repudiandae neque illo delectus commodi magnam explicabo autem voluptates eaque velit vero facere mollitia. Placeat rem, molestiae error obcaecati enim doloribus impedit aliquam, maiores qui minus neque.',
  },

  {
    id: '05',
    title: 'Cheese Burger',
    price: 24.0,
    image01: './images/product_04.jpg',
    image02: './images/product_08.jpg',
    image03: './images/product_09.jpg',
    category: 'Burger',

    desc: "Featuring a classic combination of rich tomato sauce, double the amount of creamy mozzarella cheese, and a sprinkle of aromatic basil leaves on a thin and crispy crust. This pizza is a cheese lover's dream, delivering a perfect harmony of flavors. Order our Double Cheese Margherita and treat yourself to a delightful and cheesy indulgence.",
  },
  {
    id: '06',
    title: 'Royal Cheese Burger',
    price: 24.0,
    image01: './images/product_01.1.jpg',
    image02: './images/product_01.jpg',
    image03: './images/product_01.3.jpg',
    category: 'Burger',

    desc: 'Experience royalty on a bun with our Royal Cheese Burger. Made with a juicy beef patty, layered with melted cheese, crispy lettuce, fresh tomatoes, and a special sauce, all sandwiched between soft and toasted buns. This burger is a delightful combination of flavors and textures that will satisfy your cravings. Order our Royal Cheese Burger for a truly regal dining experience delivered straight to your door.',
  },

  {
    id: '07',
    title: 'Seafood Pizza',
    price: 115.0,
    image01: './images/product_2.2.jpg',
    image02: './images/product_2.1.jpg',
    image03: './images/product_2.3.jpg',
    category: 'Pizza',

    desc: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Soluta ad et est, fugiat repudiandae neque illo delectus commodi magnam explicabo autem voluptates eaque velit vero facere mollitia. Placeat rem, molestiae error obcaecati enim doloribus impedit aliquam, maiores qui minus neque.',
  },

  {
    id: '08',
    title: 'Thin Cheese Pizza',
    price: 110.0,
    image01: './images/product_3.2.jpg',
    image02: './images/product_3.1.jpg',
    image03: './images/product_3.3.jpg',
    category: 'Pizza',

    desc: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Soluta ad et est, fugiat repudiandae neque illo delectus commodi magnam explicabo autem voluptates eaque velit vero facere mollitia. Placeat rem, molestiae error obcaecati enim doloribus impedit aliquam, maiores qui minus neque.',
  },

  {
    id: '09',
    title: 'Pizza With Mushroom',
    price: 110.0,
    image01: './images/product_4.3.png',
    image02: './images/product_4.1.jpg',
    image03: './images/product_4.2.jpg',
    category: 'Pizza',

    desc: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Soluta ad et est, fugiat repudiandae neque illo delectus commodi magnam explicabo autem voluptates eaque velit vero facere mollitia. Placeat rem, molestiae error obcaecati enim doloribus impedit aliquam, maiores qui minus neque.',
  },

  {
    id: '10',
    title: 'Classic Hamburger',
    price: 24.0,
    image01: './images/product_08.jpg',
    image02: './images/product_04.jpg',
    image03: './images/product_09.jpg',
    category: 'Burger',

    desc: 'Savor the juiciness and irresistible flavor of our Chicken Burger. Made with succulent grilled chicken breast, nestled between two soft and toasted buns, and layered with fresh lettuce, tomatoes, and a tangy special sauce.',
  },

  {
    id: '11',
    title: 'Crunchy Bread ',
    price: 35.0,
    image01: './images/bread(1).png',
    image02: './images/bread(2).png',
    image03: './images/bread(3).png',
    category: 'Bread',

    desc: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Soluta ad et est, fugiat repudiandae neque illo delectus commodi magnam explicabo autem voluptates eaque velit vero facere mollitia. Placeat rem, molestiae error obcaecati enim doloribus impedit aliquam, maiores qui minus neque.',
  },

  {
    id: '12',
    title: 'Delicious Bread ',
    price: 35.0,
    image01: './images/bread(2).png',
    image02: './images/bread(1).png',
    image03: './images/bread(3).png',
    category: 'Bread',

    desc: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Soluta ad et est, fugiat repudiandae neque illo delectus commodi magnam explicabo autem voluptates eaque velit vero facere mollitia. Placeat rem, molestiae error obcaecati enim doloribus impedit aliquam, maiores qui minus neque.',
  },

  {
    id: '13',
    title: 'Loaf Bread ',
    price: 35.0,
    image01: './images/bread(3).png',
    image02: './images/bread(2).png',
    image03: './images/bread(1).png',
    category: 'Bread',

    desc: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Soluta ad et est, fugiat repudiandae neque illo delectus commodi magnam explicabo autem voluptates eaque velit vero facere mollitia. Placeat rem, molestiae error obcaecati enim doloribus impedit aliquam, maiores qui minus neque.',
  },
  {
    id: '14',
    title: 'Hot Pizza',
    price: 110.0,
    image01: './images/product_4.2.jpg',
    image02: './images/product_4.1.jpg',
    image03: './images/product_4.3.png',
    category: 'Pizza',

    desc: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Soluta ad et est, fugiat repudiandae neque illo delectus commodi magnam explicabo autem voluptates eaque velit vero facere mollitia. Placeat rem, molestiae error obcaecati enim doloribus impedit aliquam, maiores qui minus neque.',
  },
  {
    id: '15',
    title: 'Normal Hamburger',
    price: 24.0,
    image01: './images/product_01.3.jpg',
    image02: './images/product_08.jpg',
    image03: './images/product_04.jpg',
    category: 'Burger',

    desc: 'Experience royalty on a bun with our Royal Cheese Burger. Made with a juicy beef patty, layered with melted cheese, crispy lettuce, fresh tomatoes, and a special sauce, all sandwiched between soft and toasted buns. This burger is a delightful combination of flavors and textures that will satisfy your cravings. Order our Royal Cheese Burger for a truly regal dining experience delivered straight to your door.',
  },
  {
    id: '16',
    title: 'Cheese Burger',
    price: 24.0,
    image01: './images/product_09.jpg',
    image02: './images/product_04.jpg',
    image03: './images/product_08.jpg',
    category: 'Burger',

    desc: 'Savor the juiciness and irresistible flavor of our Chicken Burger. Made with succulent grilled chicken breast, nestled between two soft and toasted buns, and layered with fresh lettuce, tomatoes, and a tangy special sauce. This mouthwatering burger is a perfect blend of savory and satisfying, delivering a delightful taste experience. Order our Chicken Burger now and treat yourself to a delicious and fulfilling meal.',
  },
  {
    id: '17',
    title: 'Special Pizza',
    price: 110.0,
    image01: './images/product_2.3.jpg',
    image02: './images/product_4.1.jpg',
    image03: './images/product_4.3.png',
    category: 'Pizza',

    desc: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Soluta ad et est, fugiat repudiandae neque illo delectus commodi magnam explicabo autem voluptates eaque velit vero facere mollitia. Placeat rem, molestiae error obcaecati enim doloribus impedit aliquam, maiores qui minus neque.',
  },
  {
    id: '18',
    title: 'Green Pizza',
    price: 110.0,
    image01: './images/product_3.3.jpg',
    image02: './images/product_4.1.jpg',
    image03: './images/product_4.3.png',
    category: 'Pizza',

    desc: 'Indulge in the flavorsome delight of our Vegetarian Pizza. Topped with a medley of garden-fresh vegetables, including bell peppers, mushrooms, onions, and juicy tomatoes, all nestled on a crispy crust smothered with tangy tomato sauce and melted cheese. This vegetarian delight is a perfect choice for those seeking a mouthwatering and satisfying pizza experience. Order our Vegetarian Pizza now and enjoy a burst of veggie goodness delivered right to your doorstep.',
  },
];

export default products;
